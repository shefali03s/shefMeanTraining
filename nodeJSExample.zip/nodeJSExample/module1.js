function addTwoNumbers(p1,p2){
    return  p1+p2;
}

function subTwoNumbers(p1,p2){
    return  p1-p2;
}

var n1=10,n2=20;
var result =addTwoNumbers(n1,n2);
console.log("addition result from module 1 : ",result);

var result =subTwoNumbers(n1,n2);
console.log("Subtraction result from module 1 : ",result);

module.exports = { addTwoNumbers , subTwoNumbers } ; //exporting function

//module.exports=n1,n2; // exporting variable 