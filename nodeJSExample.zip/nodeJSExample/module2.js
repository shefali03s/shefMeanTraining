
var { addTwoNumbers , subTwoNumbers } = require("./module1"); //user defined module


var result = addTwoNumbers(20,20);
console.log("Result from module 2 ",result);