//this is example of callbackhell example

var fs=require("fs"); // fs is core module;inbuilt module

console.log("Combined write operation started");

fs.readFile("file1.txt", (err, fileData1) => {
  if (err) {
    console.log("Error reading file1.txt:", err);
  }
  fs.readFile("file2.txt",  (err, fileData2) => {
    if (err) {
      console.log("Error reading file2", err);
     
    }
    fs.readFile("file3.txt", (err, fileData3) => {
      if (err) {
        console.log("Error reading file3", err);
      }

      var allData = fileData1 + "\n" + fileData2 + "\n" + fileData3;

      fs.writeFile("file4.txt", allData, (err) => {
        if (err) {
          console.log("Error while writing: ", err);
        } 
        else {
          console.log("Write operation completed");
        }
      });
    });
  });
});