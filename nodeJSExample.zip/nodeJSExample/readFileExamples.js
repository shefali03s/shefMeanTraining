var fs=require("fs"); // fs is core module;inbuilt module

 console.log("Start  of Async File read operation ");
fs.readFile("file1.txt",(err,data) => {
    if(err) {
        console.log("No such file",err);
    }
    else{
         console.log("File content : ",data.toString());
    }

});

console.log("End of operation ");

fs.writeFile("file2.txt","Today is tuesday.Welcome To Marsh",{flag: "a"},(err)=>{ // a stands for append in file
    if(err){
        console.log("No such file",err);
    }
    else{
         console.log("Write operation Completed");
    }
}); 

