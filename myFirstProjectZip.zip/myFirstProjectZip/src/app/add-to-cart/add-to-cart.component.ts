import { Component, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output, SimpleChanges } from '@angular/core';
import { Products } from '../model/Products';
import { Cart } from '../Cart';

@Component({
  selector: 'app-add-to-cart',
  templateUrl: './add-to-cart.component.html',
  styleUrls: ['./add-to-cart.component.css']
})
export class AddToCartComponent implements OnInit,OnChanges,OnDestroy {
  quantitySelected: number;
@Input() companyName: string; //@Input is going to get data from parent
@Input("selProduct") product : Products | null;
@Output() sendDataFromAddToCartToPD: EventEmitter<Cart | null>;
@Output() sendCancelEventFromAddToCart: EventEmitter<Cart | null>;

constructor()
{
  this.product=null;
  this.companyName="";
  this.quantitySelected=1;
  this.sendDataFromAddToCartToPD= new EventEmitter<Cart | null>();
  this.sendCancelEventFromAddToCart=new EventEmitter<Cart | null>();
}
  ngOnDestroy(): void {
   alert(" Items Selected : "+this.product?.productId);
    //throw new Error('Method not implemented.');
  }
  ngOnChanges(changes: SimpleChanges): void {
    console.log("ngOnChanges is called " , changes);
    if(changes['product'] && changes['product'].previousValue && changes['product'].currentValue.productId != changes['product'].previousValue.productId) {
      this.quantitySelected=1;
    }
    //throw new Error('Method not implemented.');
  }

ngOnInit() {
  console.log("ngoninit triggered");
}

modifyQuantity (op:string){
if(op=="dec") {

  if(this.quantitySelected>0)
  {
    this.quantitySelected--;
  }
}
else {
  if(this.product && (this.quantitySelected < this.product.quantity)) {
        this.quantitySelected =this.quantitySelected+1;
  }
      
     }
}

confirmEventHandler (){
  console.log("confirmEventHandler is triggered");
  var cartObj: Cart|null =this.product? new Cart(this.product.productId,this.product.productName,this.product.imageUrl,this.product.description,this.product.price,this.product.quantity,this.quantitySelected):null ;
  this.sendDataFromAddToCartToPD.emit(cartObj);
}

cancelEventHandler(){
 console.log("cancelEventHandler is triggered");
 
 this.sendCancelEventFromAddToCart.emit();
}
}
