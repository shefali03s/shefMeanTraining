import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { RegisterTemplateComponent } from './register-template/register-template.component';
import { TwoWayDataBindingExampleComponent } from './two-way-data-binding-example/two-way-data-binding-example.component';
import { SearchProductsComponent } from './search-products/search-products.component';
import { DirectiveExamplesComponent } from './directive-examples/directive-examples.component';
import { AddToCartComponent } from './add-to-cart/add-to-cart.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { PaymentsComponent } from './payments/payments.component';
import { PaymentByCardComponent } from './payment-by-card/payment-by-card.component';
import { PaymentByNetBankingComponent } from './payment-by-net-banking/payment-by-net-banking.component';
import { PaymentByUPIComponent } from './payment-by-upi/payment-by-upi.component';
import { ProductDisplayComponent } from './product-display/product-display.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
 
const routes: Routes = [
  {path:"products",component:HomeComponent},
  {path:"productDetails",component:ProductDetailsComponent},
  {path:"productDisplay",component:ProductDisplayComponent}, 
  {path:"searchProducts",component:SearchProductsComponent},
  {path:"registerTemplate",component:RegisterTemplateComponent},
  {path:"twoWayDataBindingExample",component:TwoWayDataBindingExampleComponent},
  {path:"directiveExample",component:DirectiveExamplesComponent},
  {path:"addToCart",component:AddToCartComponent},
  {path:"payments",component:PaymentsComponent,
    children:[
     {path:"card",component:PaymentByCardComponent},
     {path:"netbanking",component:PaymentByNetBankingComponent},
     {path:"upi",component:PaymentByUPIComponent},
     {path:"",redirectTo:"card",pathMatch:"full"},
  ]},
  {path:"",redirectTo:"products",pathMatch:"full"},
  {path:"**",component:PageNotFoundComponent}
];
 
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }