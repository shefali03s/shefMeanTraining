export function validateEmailPattern(){
    
}