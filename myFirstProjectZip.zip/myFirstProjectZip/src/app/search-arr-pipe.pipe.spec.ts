import { SearchArrPipePipe } from './search-arr-pipe.pipe';

describe('SearchArrPipePipe', () => {
  it('create an instance', () => {
    const pipe = new SearchArrPipePipe();
    expect(pipe).toBeTruthy();
  });
});
