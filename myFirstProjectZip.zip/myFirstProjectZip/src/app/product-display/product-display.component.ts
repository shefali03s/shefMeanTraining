import { Component } from '@angular/core';
import { Products } from '../model/Products';
import { Cart } from '../Cart';

@Component({
  selector: 'app-product-display',
  templateUrl: './product-display.component.html',
  styleUrls: ['./product-display.component.css']
})
export class ProductDisplayComponent {

  productsArr:Products[];
  showAddToCart:boolean;
  companyName:string;
  selectedProduct: Products | null;

  constructor(){
    this.companyName="Marsh";
    this.showAddToCart=false;
    this.selectedProduct= null;

    this.productsArr=[
          new Products(101,"iPhone11","../assets/iPhone11.jpg","iphone 11",20000,10),
          new Products(102,"iPhone12","../assets/iPhone12.jpg","iphone 12",30000,3),
          new Products(103,"iPhone13","../assets/iPhone13.jpg","iphone 13",40000,4),
          new Products(104,"iPhone14","../assets/iPhone14.jpg","iphone 14",50000,15),
          new Products(105,"iPhone15","../assets/iPhone15.jpg","iphone 15",10000,10)
    ]

  }
  addTocart(selectedProduct:Products)
  {
    this.showAddToCart=true;
    this.selectedProduct=selectedProduct;
    //alert("buttnon click : "+selectedProduct.productName);
  }
  sendDataFromAddToCartToPDEventHandler(cartObj:Cart|null)
  {
    if(cartObj!=null)
    {
      var pos=this.productsArr.findIndex(product => product.productId == cartObj.productId);
      if(pos>=0)
      {
        this.productsArr[pos].quantity=this.productsArr[pos].quantity-cartObj.quantitySelected;
      }
      this.showAddToCart=false; //unmount child component
      this.selectedProduct=null;
    }
  }

  sendCancelEventFromAddToCartToPDEventHandler()
  {

  }
}
