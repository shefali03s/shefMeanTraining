import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchArrPipe'
})
export class SearchArrPipePipe implements PipeTransform {

  transform(value: any[], searchText:string,fieldName: string) :any[] {
    if(searchText== "")
    {
      return value;
    }
    if(fieldName== "")
    {
      return value;
    }
   var filteredArr= value.filter(element =>{
      if(element[fieldName].toString().includes(searchText)){
        return element;
      } 
    } )
      return filteredArr;
  }
}
