import { Directive, ElementRef, HostListener, Input, OnInit } from '@angular/core';

@Directive({
  selector: '[appBgColor]'
})
export class BgColorDirective implements OnInit{
  @Input() appBgColor : string;

@HostListener('mouseenter') onMouseEnter()
{
   this.elementRef.nativeElement.style.backgroundColor= 'yellow';
   this.elementRef.nativeElement.style.color= 'black';
}
@HostListener('mouseleave') onMouseLeave()
{
   this.elementRef.nativeElement.style.backgroundColor=this.appBgColor?this.appBgColor:'red';
}
  constructor(private elementRef : ElementRef) { 
    this.appBgColor='red';
    elementRef.nativeElement.style.backgroundColor= 'red';
    elementRef.nativeElement.style.color= 'white';
  }
  ngOnInit(): void {
    if(this.appBgColor)
    {
      this.elementRef.nativeElement.style.backgroundColor= this.appBgColor;
    }
    
  }

}
