import { Component,ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  encapsulation:ViewEncapsulation.None  //CSS will be applied to entire application
 // encapsulation:ViewEncapsulation.Emulated //CSS will be applied to corresonding component
 // encapsulation:ViewEncapsulation.ShadowDom //CSS will be applied to component and its children
})
export class AppComponent {
  title = 'myFirstProject';
  companyName:string;
  fruits:string[];
  empObj:any;
  isMember:boolean;
  empBDay:Date;
  imgURL:string;

  constructor(){
    this.companyName="Marsh";
    this.fruits=["Apple","Banana","Mango"];
    this.empObj={empId:101,empName:"Shefali",empSalary:"123"};
    this.isMember=true;
    this.empBDay =new Date(2020,1,22);
    this.imgURL="../assets/marsh-logo.png";
  }

}
