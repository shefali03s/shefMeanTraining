import { Component } from '@angular/core';
import { Products } from '../model/Products';

@Component({
  selector: 'app-search-products',
  templateUrl: './search-products.component.html',
  styleUrls: ['./search-products.component.css']
})
export class SearchProductsComponent {
   productsArr: Products[];
  searchText: string;
  fieldName: string;
  fieldNameArr: string[];
  selectedProduct: Products | null;
   
constructor(){
    this.searchText = "";
    this.fieldName = "";
    this.fieldNameArr = ["productId", "productName", "price", "quantity", "description"];
    this.selectedProduct = null;

   this.productsArr=[
            new Products(101,"iPhone11","../assets/iPhone11.jpg","iphone 11",20000,10),
            new Products(102,"iPhone12","../assets/iPhone12.jpg","iphone 12",30000,3),
            new Products(103,"iPhone13","../assets/iPhone13.jpg","iphone 13",40000,4),
            new Products(104,"iPhone14","../assets/iPhone14.jpg","iphone 14",50000,15),
            new Products(105,"iPhone15","../assets/iPhone15.jpg","iphone 15",10000,10)
      ]
}

 searchEventHandler(text: string, fieldName: string) {
    this.searchText = text;
    this.fieldName = fieldName;
  }

editEventHandler(selectedProduct: Products) {
    this.selectedProduct = selectedProduct;
  }
}
