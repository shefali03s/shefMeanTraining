import { Directive } from '@angular/core';
import { AbstractControl, NG_VALIDATORS, ValidationErrors, Validator } from '@angular/forms';
import { validateEmailPattern } from './validateEmailPattern';

@Directive({
  selector: '[appCheckEmailPattern]',
  providers:[
    {provide: NG_VALIDATORS,useExisting:CheckEmailPatternDirective,multi:true}
  ]
})
export class CheckEmailPatternDirective implements Validator {

  constructor() { }
  validate(control: AbstractControl): ValidationErrors | null {
   var passTest:boolean=true;
   if(/[A-Z]/.test(control.value) && /[a-z]/.test(control.value)){
    return null;
   }
   else{
    return {emailpattern:true}
   }
  }

}
