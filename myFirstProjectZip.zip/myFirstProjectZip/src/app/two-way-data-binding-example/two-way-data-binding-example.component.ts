import { Component } from '@angular/core';

@Component({
  selector: 'app-two-way-data-binding-example',
  templateUrl: './two-way-data-binding-example.component.html',
  styleUrls: ['./two-way-data-binding-example.component.css']
})
export class TwoWayDataBindingExampleComponent {
countryName:string;
personName:string;
constructor(){
  this.countryName="India";
  this.personName="shefali";
}

inputEventHandler(event : any){
  console.log("inputEventHandler triggered",event.target.value);
  this.countryName=event.target.value;
}
}
