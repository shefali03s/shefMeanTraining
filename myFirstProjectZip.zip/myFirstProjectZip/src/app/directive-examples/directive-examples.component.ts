import { Component } from '@angular/core';

@Component({
  selector: 'app-directive-examples',
  templateUrl: './directive-examples.component.html',
  styleUrls: ['./directive-examples.component.css']
})
export class DirectiveExamplesComponent {
myFavColor :string;
constructor(){
  this.myFavColor="pink";
}
}
